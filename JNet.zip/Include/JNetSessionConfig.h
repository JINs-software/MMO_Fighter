#pragma once

#define SESSION_RECV_BUFF 20000
#define SESSION_SEND_BUFF 20000