#pragma once

typedef unsigned int HostID;